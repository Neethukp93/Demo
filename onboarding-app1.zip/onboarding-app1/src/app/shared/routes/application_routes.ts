/**
 * @description Route urls for the application
 * @author Neethu KP
 */
export const APPLICATION_ROUTES = {
	ADMIN_LOGIN: 'admin/login',
	ADMIN_HOME: 'admin/home',
	EDIT_TENANT: 'admin/edit-tenant/'
};
