import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-tenant-details',
  templateUrl: './edit-tenant-details.component.html',
  styleUrls: ['./edit-tenant-details.component.scss']
})
export class EditTenantDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
