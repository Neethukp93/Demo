import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { PrimengModule } from '../shared/modules/primeng.module';
import { MaterialModule } from '../shared/modules/material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { EditTenantDetailsComponent } from './edit-tenant-details/edit-tenant-details.component';



@NgModule({
  declarations: [LoginComponent, HomeComponent, EditTenantDetailsComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MaterialModule,
    PrimengModule
  ]
})
export class AdminModule { }
