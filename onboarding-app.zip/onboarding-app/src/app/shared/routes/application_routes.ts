/**
 * @description Route urls for the application
 * @author Neethu KP
 */
export const APPLICATION_ROUTES = {
	EDI_CANCEL: 'sgedi/edi-cancel'
};
