export class PermitData {
	index?: number;
	cycleDate?: string;
	cycleNo: string;
	flightNo: string;
	gateway?: string;
	hawbNo: string;
	isBondIn: string | boolean;
	isBondOut: string | boolean;
	mawbNo: string;
	permitNo?: string;
	routeDate?: string;
	routeLegNo?: number;
	routeNo?: string;
	shipOid?: number;
	status: string;
	taskName: string;
	updateBy?: string;
	updateDate?: string;
	okToSend?: boolean;
}
