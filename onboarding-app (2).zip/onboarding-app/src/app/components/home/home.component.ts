import { Component, OnInit } from '@angular/core';
import { TenantData } from 'src/app/shared/models/TenantData.model';
import { AdminDataService } from 'src/app/shared/services/admin-data.service';
import { Router } from '@angular/router';
import { APPLICATION_ROUTES } from 'src/app/shared/routes/application_routes';
import { AuthenticationService } from 'src/app/shared/services/authentication.service';
import { User } from 'src/app/shared/models/user';
import { Role } from 'src/app/shared/models/role';

@Component({
	selector: 'app-home',
	templateUrl: './home.component.html',
	styleUrls: [ './home.component.scss' ]
})
export class HomeComponent implements OnInit {
	currentUser: User;
	constructor(private authenticationService: AuthenticationService, private router: Router) {}

	ngOnInit() {
		this.authenticationService.currentUser.subscribe((x) => (this.currentUser = x));
	}

	get isAdmin() {
		return this.currentUser && this.currentUser.role === Role.Admin;
	}

	get isTenant() {
		return this.currentUser && this.currentUser.role === Role.Tenant;
	}
}
