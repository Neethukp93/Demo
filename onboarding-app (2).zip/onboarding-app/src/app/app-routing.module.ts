import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { APPLICATION_ROUTES } from './shared/routes/application_routes';
import { LoginComponent } from './components/login/login.component';
import { AuthGuard } from './core/auth.guard';
import { EditTenantDetailsComponent } from './admin/edit-tenant-details/edit-tenant-details.component';
import { Role } from './shared/models/role';
import { HomeComponent } from './components/home/home.component';

const routes: Routes = [
	{
		path: APPLICATION_ROUTES.LOGIN,
		component: LoginComponent
	},
	{
		path: APPLICATION_ROUTES.HOME,
		component: HomeComponent,
		canActivate: [ AuthGuard ]
	},
	{
		path: APPLICATION_ROUTES.EDIT_TENANT + ':id',
		component: EditTenantDetailsComponent,
		canActivate: [ AuthGuard ],
		data: { roles: [ Role.Admin ] }
	},
	{
		path: APPLICATION_ROUTES.ONBOARDING + ':id',
		component: EditTenantDetailsComponent,
		canActivate: [ AuthGuard ],
		data: { roles: [ Role.Tenant ] }
	},
	// otherwise redirect to admin login
	{ path: '**', redirectTo: APPLICATION_ROUTES.LOGIN }
];

@NgModule({
	imports: [ RouterModule.forRoot(routes, { enableTracing: true }) ],
	exports: [ RouterModule ]
})
export class AppRoutingModule {}
