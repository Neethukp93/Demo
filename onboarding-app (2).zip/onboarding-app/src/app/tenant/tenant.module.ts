import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrimengModule } from '../shared/modules/primeng.module';
import { MaterialModule } from '../shared/modules/material.module';

@NgModule({
	declarations: [],
	imports: [ CommonModule, PrimengModule, MaterialModule ]
})
export class TenantModule {}
