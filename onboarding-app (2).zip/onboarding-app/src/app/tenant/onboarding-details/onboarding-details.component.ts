import { Component, OnInit } from '@angular/core';
import { SelectItem } from 'primeng/api';
import { UtilityService } from 'src/app/shared/services/utility.service';
import { AuthenticationService } from 'src/app/shared/services/authentication.service';
import { AdminDataService } from 'src/app/shared/services/admin-data.service';
import { TenantData } from 'src/app/shared/models/TenantData.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
	selector: 'app-onboarding-details',
	templateUrl: './onboarding-details.component.html',
	styleUrls: [ './onboarding-details.component.scss' ]
})
export class OnboardingDetailsComponent implements OnInit {
	accountsList: SelectItem[] = [];
	tenantSettings: TenantData;
	tenantForm: FormGroup;
	credentialForm: FormGroup;
	personalForm: FormGroup;
	addressform: FormGroup;
	countryList: SelectItem[] = [];
	addressCountryList: SelectItem[] = [];
	showCredentialTemplate: boolean = false;
	showPersonalInfoTemplate: boolean = false;
	showAddressTemplate: boolean = false;
	showConfirmTemplate: boolean = false;
	isEditView: boolean = false;
	constructor(
		private authService: AuthenticationService,
		private utilityService: UtilityService,
		private dataService: AdminDataService,
		private fb: FormBuilder
	) {}

	ngOnInit() {
		this.countryList = this.utilityService.getCountryList();
		this.addressCountryList = this.utilityService.getAddressCountryList();
		const currentUser = this.authService.currentUserValue;
		if (currentUser) {
			this.getTenantDetails(currentUser.id);
		}
	}

	getTenantDetails(tenantId: string) {
		this.dataService.getTenantsettings(tenantId).subscribe((details: TenantData) => {
			this.tenantSettings = details;
			this.accountsList = this.utilityService.getDropdownList(this.tenantSettings.configuration.accountTypes);
			//	this.credentialForm = ;
			//this.personalForm = this.addressform =
			this.tenantForm = this.fb.group({
				accountType: [ '', Validators.required ],
				credentials: this.fb.group({
					firstName: [ '', Validators.required ],
					lastName: [ '', Validators.required ],
					username: [ '', Validators.required ],
					email: [ '', Validators.email ],
					country: [ '', Validators.required ],
					acceptTerms: [ '', Validators.required ]
				}),
				personalDetails: this.fb.group({
					passportNumber: [ '', Validators.required ],
					passportExpiry: [ '', Validators.required ],
					personalNumber: [ '', Validators.required ],
					country: [ '', Validators.required ]
				}),
				addressDetails: this.fb.group({
					addresLine1: [ '', Validators.required ],
					addressLine2: [ '', Validators.required ],
					city: [ '', Validators.required ],
					country: [ '', Validators.required ]
				})
			});
			// if (this.tenantSettings.configuration.askCredentials) {
			// 	this.tenantForm.addControl('credentials', this.credentialForm);
			// }
			// if (this.tenantSettings.configuration.askAddressDetails) {
			// 	this.tenantForm.addControl('addressDetails', this.addressform);
			// }
		});
	}

	accountChange() {
		if (this.tenantSettings.configuration) {
			if (this.tenantSettings.configuration.askCredentials) {
				this.showCredentialTemplate = true;
			} else {
				this.showPersonalInfoTemplate = true;
			}
		}
	}

	signUp() {
		this.showPersonalInfoTemplate = true;
	}

	nextFromPersonalInfo() {
		this.showAddressTemplate = true;
	}

	nextFromAddressInfo() {
		this.showCredentialTemplate = this.showPersonalInfoTemplate = this.showAddressTemplate = false;
		this.showConfirmTemplate = true;
	}

	editClick() {
		this.showCredentialTemplate = this.showPersonalInfoTemplate = this.showAddressTemplate = true;
		this.isEditView = true;
		this.showConfirmTemplate = false;
	}

	onSubmit() {
		if (this.tenantForm.valid) {
			console.log(this.tenantForm.value);
		}
	}
}
