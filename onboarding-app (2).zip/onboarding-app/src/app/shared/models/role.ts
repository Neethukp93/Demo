export enum Role {
	Tenant = 'Tenant',
	Admin = 'Admin'
}
