import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AdminDataService {
	constructor(private http: HttpClient) {}

	public getTenantDetails(): Observable<any> {
		return this.http.get('./assets/utility/TenantDetails.json');
	}

	getTenantsettings(id: string) {
		if (id === 'beef29f2-14e9-11ea-8d71-362b9e155667') {
			return this.http.get('./assets/utility/tenantSettingsMock.beef29f2-14e9-11ea-8d71-362b9e155667.json');
		} else {
			return this.http.get('./assets/utility/tenantSettingsMock.c4c17984-14e9-11ea-8d71-362b9e155667.json');
		}
	}
}
