import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TenantsListsComponent } from './tenants-lists.component';

describe('TenantsListsComponent', () => {
	let component: TenantsListsComponent;
	let fixture: ComponentFixture<TenantsListsComponent>;

	beforeEach(
		async(() => {
			TestBed.configureTestingModule({
				declarations: [ TenantsListsComponent ]
			}).compileComponents();
		})
	);

	beforeEach(() => {
		fixture = TestBed.createComponent(TenantsListsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
