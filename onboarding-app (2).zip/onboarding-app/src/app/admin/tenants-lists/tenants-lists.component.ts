import { Component, OnInit } from '@angular/core';
import { TenantData } from 'src/app/shared/models/TenantData.model';
import { AdminDataService } from 'src/app/shared/services/admin-data.service';
import { Router } from '@angular/router';
import { APPLICATION_ROUTES } from 'src/app/shared/routes/application_routes';

@Component({
	selector: 'app-tenants-list',
	templateUrl: './tenants-lists.component.html',
	styleUrls: [ './tenants-lists.component.scss' ]
})
export class TenantsListsComponent implements OnInit {
	tenantsTableData: TenantData[];
	constructor(private dataService: AdminDataService, private router: Router) {}

	ngOnInit() {
		this.dataService.getTenantDetails().subscribe((details) => {
			this.tenantsTableData = details;
		});
	}

	editTenantDetails(tenantDetails: TenantData) {
		this.router.navigate([ APPLICATION_ROUTES.EDIT_TENANT, tenantDetails.tenantId ]);
	}
}
