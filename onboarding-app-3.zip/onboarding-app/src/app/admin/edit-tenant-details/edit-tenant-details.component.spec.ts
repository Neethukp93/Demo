import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditTenantDetailsComponent } from './edit-tenant-details.component';

describe('EditTenantDetailsComponent', () => {
  let component: EditTenantDetailsComponent;
  let fixture: ComponentFixture<EditTenantDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditTenantDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditTenantDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
