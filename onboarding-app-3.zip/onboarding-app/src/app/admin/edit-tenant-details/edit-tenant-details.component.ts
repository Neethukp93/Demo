import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiDataService } from '../../shared/services/api-data.service';
import { TenantData } from '../../shared/models/TenantData.model';
import { UtilityService } from '../../shared/services/utility.service';
import { SelectItem, MessageService } from 'primeng/api';
import { CustomValidator } from '../../shared/validators/CustomValidator';
import { ThemeService } from '../../shared/services/theme.service';
import { Globals } from '../../shared/globals/globals';

@Component({
  selector: 'app-edit-tenant-details',
  templateUrl: './edit-tenant-details.component.html',
  styleUrls: ['./edit-tenant-details.component.scss']
})

export class EditTenantDetailsComponent implements OnInit {
  editForm: FormGroup;
  configuration: FormGroup;
  submitted = false;
  mainColors: SelectItem[] = [];
  secondaryColors: SelectItem[] = [];
  accountLists: SelectItem[] = [];
  currentTenantDetails: TenantData;
  editFormData: TenantData;
  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute, 
    private apiDataService: ApiDataService, private utilityServices: UtilityService,
    private messageService: MessageService, private themeService:ThemeService , private globals:Globals) { }

  ngOnInit() {
    this.globals.showLoader();
    this.mainColors = [{label: 'Black' , value : '#2a2a32'}, { label : 'Green' , value:'#2b7a2b'} , { label : 'Blue' , value:'#0b72c2'}]; // this.utilityServices.getDropdownList(['Black', 'Green', 'Orange']);
    this.secondaryColors = [{label: 'White' , value : '#fff'}, { label : 'Light Grey' , value:'#a6a6a629'} , { label : 'Light Cyan' , value:'#e8f6f6'}]; // this.utilityServices.getDropdownList(['White', 'Ash']);
    this.accountLists = this.utilityServices.getDropdownList([ 'Individual', 'Joint', 'Business']);
    console.log(this.mainColors)
    this.route.paramMap.subscribe((params) => {
      const tenantId = params.get('id');
      if (tenantId) {
        this.getTenant(tenantId);
      }
    })
    this.configuration = this.formBuilder.group({
      accountTypes: ['', Validators.required],
      askAddressDetails: [false, Validators.required],
      askCredentials: [false, Validators.required],
      customConfirm: [false, Validators.required]
    })
    this.editForm = this.formBuilder.group({
      tenantName: ['', Validators.required],
      tenantId: [{ value: '', disabled: true }, Validators.required],
      mainColor: ['', Validators.required], // new FormControl(2),//[1, Validators.required ],
      secondaryColor: ['', Validators.required],
      username: [{ value: '', disabled: true }, Validators.required],
      password: [{ value: '', disabled: true }, Validators.required],
      configuration: this.configuration

    });

    //this.formValueChanges();
  }


  get f() { return this.editForm.controls; }

  // formValueChanges(){
  // 	this.editForm.valueChanges
  //       .subscribe((value) => {
  // 		console.log(value);
  //             this.editFormData  = value;
  //             if(this.editFormData.configuration.customConfirm ){
  //               this.configuration.addControl('url',new FormControl([ Validators.required , CustomValidator.urlValidator]))
  //             }
  //       });
  // }

  getTenant(tenantId: string) {
    this.apiDataService.getTenantSettings(tenantId).subscribe(
      (details: TenantData) => {
        console.log(details);
        this.currentTenantDetails = details;
        this.editTenant(details);
        this.globals.hideLoader();
      },
      (err) => console.log(err)
    )
  }

  editTenant(tenantDetails: TenantData) {

    this.editForm.patchValue({
      tenantName: tenantDetails.tenantName,
      tenantId: tenantDetails.tenantId,
      mainColor: tenantDetails.mainColor,//{label :tenantDetails.mainColor,value:tenantDetails.mainColor} ,
      secondaryColor: tenantDetails.secondaryColor,
      username: tenantDetails.username,
      password: tenantDetails.password,
      configuration: {
        accountTypes: tenantDetails.configuration.accountTypes,
        askAddressDetails: tenantDetails.configuration.askAddressDetails,
        askCredentials: tenantDetails.configuration.askCredentials,
        customConfirm: tenantDetails.configuration.customConfirm//,
        // url:tenantDetails.configuration.url
      }
    })

    if (tenantDetails.configuration.customConfirm) {
      this.configuration.addControl('url', new FormControl(tenantDetails.configuration.url, [Validators.required, CustomValidator.urlValidator]));
      // this.editForm.setValue({configuration.url: tenantDetails.configuration.url})
    }

    this.showTemplatePreview();

    
  }


  customConfirmChange($checked) {
    if ($checked) {
      let value = this.currentTenantDetails.configuration.url ? this.currentTenantDetails.configuration.url : '';
      this.configuration.addControl('url', new FormControl(value, [Validators.required, CustomValidator.urlValidator]));
    } else {
      this.configuration.removeControl('url');
    }
  }


  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.editForm.invalid) {
      this.messageService.add({ severity: 'error', key: 'app-toastr', summary: 'Error', detail: 'Validation errors occured !' });
      return;
    }
    this.messageService.add({ severity: 'success', key: 'app-toastr', summary: 'Success', detail: 'Details Updated Succeesfully !' });
    // display form values on success
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.editForm.value, null, 4));
  }

  onReset() {
    this.submitted = false;
    this.getTenant(this.currentTenantDetails.tenantId);
  }

  showTemplatePreview(){
    if(this.f.mainColor.value){
      this.themeService.setPreviewPrimaryColor(this.f.mainColor.value);
    }
    if(this.f.secondaryColor.value){
      this.themeService.setPreviewSecondaryColor(this.f.secondaryColor.value);
    }
  }

  

}
