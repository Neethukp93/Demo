import { Component, OnInit } from '@angular/core';
import { TenantData } from '../../shared/models/TenantData.model';
import { ApiDataService } from '../../shared/services/api-data.service';
import { Router } from '@angular/router';
import { APPLICATION_ROUTES } from '../../shared/routes/application_routes';
import { UtilityService } from '../../shared/services/utility.service';

@Component({
	selector: 'app-tenants-list',
	templateUrl: './tenants-lists.component.html',
	styleUrls: ['./tenants-lists.component.scss']
})
export class TenantsListsComponent implements OnInit {
	tenantsTableData: TenantData[];
	constructor(private dataService: ApiDataService, private router: Router, private utilityServices: UtilityService) { }

	ngOnInit() {
		this.dataService.getTenantDetails().subscribe((details) => {
			this.tenantsTableData = details;
		});
	}

	editTenantDetails(tenantDetails: TenantData) {
		this.router.navigate([APPLICATION_ROUTES.EDIT_TENANT, tenantDetails.tenantId]);
	}

	getColorText(color: string) {
		return this.utilityServices.getColorText(color);
	}
}
