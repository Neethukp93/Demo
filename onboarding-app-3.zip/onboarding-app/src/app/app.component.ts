import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from './shared/services/authentication.service';
import { ThemeService } from './shared/services/theme.service';
import { User } from './shared/models/user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'onboarding-app';

  constructor(private authService: AuthenticationService, private themeService: ThemeService) {
  }

  ngOnInit() {
    this.authService.currentUser.subscribe((user: User) => {
      if (user && user.mainColor && user.secondaryColor) {
        this.themeService.setTheme(user.mainColor, user.secondaryColor);
      }
    })
  }
}
