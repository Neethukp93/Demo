/**
 * @description enum for EDI filter types
 * @author Neethu KP
 */
export enum EDI_FILTER {
	MAWB = 1,
	FLIGHT = 2,
	AWB = 3
}
