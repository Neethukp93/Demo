/**
 * @description Route urls for the application
 * @author Neethu KP
 */
export const APPLICATION_ROUTES = {
	LOGIN: 'login',
	HOME: 'home',
	TENANTS_LISTS: 'tenants-lists',
	EDIT_TENANT: 'edit-tenant/',
	ONBOARDING: 'onboarding/',
	THANK_YOU_PAGE: 'thank-you'
};
