import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
@Injectable({ providedIn: 'root' })
export class ApiDataService {
	constructor(private http: HttpClient) {}

	public getTenantDetails(): Observable<any> {
		return this.http.get('./assets/utility/TenantDetails.json');
	}

	getTenantDetailsbyId(id:string){
		return this.http.get('./assets/utility/TenantDetails.'+id+'.json');
	}

	getTenantSettings(id: string) {
		return this.http.get('./assets/utility/tenantSettingsMock.'+id+'.json');
	}

	saveTenantDetails(id:string , jsonObject:string){
		if (id) {
		//	writeJsonFile('./assets/utility/tenantRegistrationInfo.'+id+'.json', jsonObject);
			// let crlfContent = jsonObject.replace(/\r\n/g, '\n').replace(/\n/g, '\r\n');
			// writeFileSync('./assets/utility/tenantRegistrationInfo.'+id+'.json', crlfContent, { encoding: 'utf8' });
		
		  }
		// const blob = new Blob([JSON.stringify(jsonObject)], {type : 'application/json'});
		// saveAs(blob, './assets/utility/tenantRegistrationInfo.'+id+'.json');
	}


	
}
