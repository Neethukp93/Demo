import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ThemeService {

    setDefaultTheme() {
        document.documentElement.style.setProperty(`--primary-color`, '#fdfd54');
        document.documentElement.style.setProperty(`--background-color`, '#fff');
        document.documentElement.style.setProperty(`--text-color`, '#2a2a32');
    }

    setTheme(primaryColor: string, secondaryColor: string) {
        document.documentElement.style.setProperty(`--primary-color`, primaryColor);
        document.documentElement.style.setProperty(`--background-color`, secondaryColor);
        document.documentElement.style.setProperty(`--text-color`, '#fff');
    }

    setPreviewPrimaryColor(primaryColor: string) {
        document.documentElement.style.setProperty(`--preview-primary`, primaryColor);
    }

    setPreviewSecondaryColor(secondaryColor: string) {
        document.documentElement.style.setProperty(`--preview-secondary`, secondaryColor);
    }


}