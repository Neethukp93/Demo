import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { User } from '../models/user';
import { UserInfoService } from './user-info.service';
import { ThemeService } from './theme.service';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
	private currentUserSubject: BehaviorSubject<User>;
	public currentUser: Observable<User>;
	constructor(private http: HttpClient, private themeService: ThemeService) {
		this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
		this.currentUser = this.currentUserSubject.asObservable();
	}

	public get currentUserValue(): User {
		return this.currentUserSubject.value;
	}

	login(username, password) {
		let loginURL = './assets/utility/loginErrorMock.json';
		if (username === 'Admin' && password === 'Admin@123') {
			loginURL = './assets/utility/adminDetailsMock.json';
		} else if (username === 'whitelabel_admin' && password === 'EAqP1X5Sp@') {
			loginURL = './assets/utility/tenantLoginInfoMock.beef29f2-14e9-11ea-8d71-362b9e155667.json';
		} else if (username === 'greelabel_admin' && password === '!36crZ*UJd') {
			loginURL = './assets/utility/tenantLoginInfoMock.c4c17984-14e9-11ea-8d71-362b9e155667.json';
		}
		return this.http.get<any>(loginURL).pipe(
			map((res) => {
				// store user details and jwt token in local storage to keep user logged in between page refreshes
				if (res.status === 'success') {
					localStorage.setItem('currentUser', JSON.stringify(res.user));
					this.currentUserSubject.next(res.user);
				}
				return res;
			})
		);
	}

	logout() {
		// remove user from local storage and set current user to null
		this.themeService.setDefaultTheme();
		localStorage.removeItem('currentUser');
		this.currentUserSubject.next(null);
	}
}
