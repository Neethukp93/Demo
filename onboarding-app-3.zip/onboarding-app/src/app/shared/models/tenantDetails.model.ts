export interface TenantDetails {
	accountType: string;
	credentials?: Credentials;
	personalDetails: PersonalDetails;
	AddressDetails?: addressDetails;
}

export interface Credentials {
	firstName: string;
	lastName: string;
	username: string;
	email: string;
    country: string;
    acceptTerms: boolean;
}
export interface PersonalDetails {
	passportNumber: string;
	passportExpiry: string;
	personalNumber: number;
    country: string;
}
export interface addressDetails {
	addresLine1: string;
	addresLine2: string;
	city: string;
    country: string;
}