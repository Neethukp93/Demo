export interface TenantData {
	tenantName: string;
	tenantId: string;
	mainColor: string;
	secondaryColor: string;
	username: string;
	password: string;
	configuration: Configuration;
}

export interface Configuration {
	accountTypes: string[];
	askAddressDetails: boolean;
	askCredentials: boolean;
	customConfirm: boolean;
	url?: string;
}
