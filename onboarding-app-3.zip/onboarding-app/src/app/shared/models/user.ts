import { Role } from "./role";

export class User {
	id: string;
	username: string;
	firstName: string;
	lastName: string;
	role: Role;
	token: string;
	logoUrl?: string;
	mainColor?: string;
	secondaryColor?: string;
}
