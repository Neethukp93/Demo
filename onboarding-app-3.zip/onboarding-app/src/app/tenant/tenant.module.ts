import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrimengModule } from '../shared/modules/primeng.module';
import { MaterialModule } from '../shared/modules/material.module';
import { ReactiveFormsModule } from '../../../node_modules/@angular/forms';
import { ConfirmationPageComponent } from './confirmation-page/confirmation-page.component';

@NgModule({
	declarations: [ConfirmationPageComponent],
	imports: [ CommonModule, PrimengModule, MaterialModule ,ReactiveFormsModule]
})
export class TenantModule {}
