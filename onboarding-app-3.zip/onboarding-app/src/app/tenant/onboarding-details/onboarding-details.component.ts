import { Component, OnInit, AfterViewInit, AfterViewChecked } from '@angular/core';
import { SelectItem, MessageService } from 'primeng/api';
import { UtilityService } from '../../shared/services/utility.service';
import { AuthenticationService } from '../../shared/services/authentication.service';
import { ApiDataService } from '../../shared/services/api-data.service';
import { TenantData } from '../../shared/models/TenantData.model';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TenantDetails } from '../../shared/models/tenantDetails.model';
import { APPLICATION_ROUTES } from '../../shared/routes/application_routes';
import { Router } from '@angular/router';

@Component({
	selector: 'app-onboarding-details',
	templateUrl: './onboarding-details.component.html',
	styleUrls: ['./onboarding-details.component.scss']
})
export class OnboardingDetailsComponent implements OnInit {
	accountsList: SelectItem[] = [];
	tenantSettings: TenantData;
	tenantForm: FormGroup;
	credentialForm: FormGroup;
	personalForm: FormGroup;
	addressform: FormGroup;
	countryList: SelectItem[] = [];
	addressCountryList: SelectItem[] = [];
	showCredentialTemplate: boolean = false;
	showPersonalInfoTemplate: boolean = false;
	showAddressTemplate: boolean = false;
	showConfirmTemplate: boolean = false;
	isEditView: boolean = false;
	tenantFormData: TenantDetails;
	submitted: boolean = false;
	constructor(
		private authService: AuthenticationService,
		private utilityService: UtilityService,
		private dataService: ApiDataService,
		private fb: FormBuilder,
		private messageService: MessageService,
		private router: Router
	) { }

	ngOnInit() {
		this.countryList = this.utilityService.getCountryList();
		this.addressCountryList = this.utilityService.getAddressCountryList();
		const currentUser = this.authService.currentUserValue;
		if (currentUser) {
			this.getTenantDetails(currentUser.id);
		}

	}

	formValueChanges() {
		this.tenantForm.valueChanges
			.subscribe((value) => {
				console.log(value);
				this.tenantFormData = value;
			});
	}

	getTenantDetails(tenantId: string) {
		this.dataService.getTenantSettings(tenantId).subscribe((details: TenantData) => {
			this.tenantSettings = details;
			this.accountsList = this.utilityService.getDropdownList(this.tenantSettings.configuration.accountTypes);
			// this.credentialForm = ;
			// this.personalForm = this.addressform =
			// const phoneNumber = "^(\+\d{1,3}[- ]?)?\d{10}$";
			this.tenantForm = this.fb.group({
				accountType: ['', Validators.required],
				personalDetails: this.fb.group({
					passportNumber: ['', Validators.required],
					passportExpiry: ['', Validators.required],
					personalNumber: ['', [Validators.required, Validators.pattern('^(\\+\\d{1,3}[- ]?)?\\d{10}$')]],
					country: ['', Validators.required]
				})
			});
			if (this.tenantSettings.configuration.askCredentials) {
				this.tenantForm.addControl('credentials', this.fb.group({
					firstName: ['', Validators.required],
					lastName: ['', Validators.required],
					username: ['', Validators.required],
					email: ['', [Validators.required, Validators.email]],
					country: ['', Validators.required],
					acceptTerms: ['', Validators.requiredTrue]
				}));
			}
			if (this.tenantSettings.configuration.askAddressDetails) {
				this.tenantForm.addControl('addressDetails', this.fb.group({
					addresLine1: ['', Validators.required],
					addressLine2: [''],
					city: ['', Validators.required],
					country: ['', Validators.required]
				}));
			}

			this.formValueChanges();
			this.f;
		});

	}

	get f() { return this.tenantForm.controls; }

	accountChange() {
		if (this.tenantSettings.configuration) {
			if (this.tenantSettings.configuration.askCredentials) {
				this.showCredentialTemplate = true;
			} else {
				this.showPersonalInfoTemplate = true;
			}
		}
	}

	signUp() {
		this.showPersonalInfoTemplate = true;
	}

	nextFromPersonalInfo() {
		if (this.tenantSettings.configuration.askAddressDetails) {
			this.showAddressTemplate = true;
		} else {
			this.nextFromAddressInfo();
		}

	}

	nextFromAddressInfo() {
		this.showCredentialTemplate = this.showPersonalInfoTemplate = this.showAddressTemplate = false;
		this.showConfirmTemplate = true;
	}

	editClick() {
		this.showCredentialTemplate = this.showPersonalInfoTemplate = this.showAddressTemplate = true;
		this.isEditView = true;
		this.showConfirmTemplate = false;
	}

	onSubmit() {
		this.submitted = true;
		this.messageService.clear();
		console.log(this.tenantForm.value);
		if (this.tenantForm.valid) {
			this.messageService.add({
				severity: 'success', key: 'app-toastr', summary: "Success", detail: "Onboarding process successfully completed !"
			})
			if (this.tenantSettings.configuration.customConfirm) {
				window.location.href = this.tenantSettings.configuration.url;
			} else {
				this.router.navigate([APPLICATION_ROUTES.THANK_YOU_PAGE]);
			}


			// this.dataService.saveTenantDetails(this.tenantSettings.tenantId,JSON.stringify(this.tenantForm.value));
		} else {
			this.messageService.add({
				severity: 'error', key: 'app-toastr', summary: "Error", detail: "Validation errors occured !"
			})
			this.editClick();
		}
	}
}
