import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../shared/services/authentication.service';
import { User } from '../../shared/models/user';
import { Router } from '@angular/router';
import { APPLICATION_ROUTES } from '../../shared/routes/application_routes';
import { MenuItem } from 'primeng/api';

@Component({
	selector: 'app-header',
	templateUrl: './header.component.html',
	styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
	userInfo: User;
	private items: MenuItem[];
	constructor(private authService: AuthenticationService, private router: Router) { }

	ngOnInit() {
		this.authService.currentUser.subscribe((user) => {
			this.userInfo = user;
		});

		this.items = [
			{
				label: 'File',

			}];
	}



	logout() {
		this.authService.logout();
		this.router.navigate([APPLICATION_ROUTES.LOGIN]);
	}
}
